-- Morningfall Creators - Backup do banco
-- Gerado em: 2026-09-03 12:30:03

SET FOREIGN_KEY_CHECKS=0;
SET SQL_MODE='NO_AUTO_VALUE_ON_ZERO';

DROP TABLE IF EXISTS `activities`;
CREATE TABLE `activities` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `streamer_id` int(10) unsigned NOT NULL,
  `type` enum('live_bonus','collab','raid','event','video','viral_video','server_promo','referral','monthly_bonus','other') NOT NULL,
  `description` varchar(255) NOT NULL,
  `points` int(11) NOT NULL DEFAULT 0,
  `activity_date` date NOT NULL,
  `evidence_url` varchar(700) DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `fk_activities_streamer` (`streamer_id`),
  KEY `fk_activities_staff` (`created_by`),
  CONSTRAINT `fk_activities_staff` FOREIGN KEY (`created_by`) REFERENCES `staff_users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_activities_streamer` FOREIGN KEY (`streamer_id`) REFERENCES `streamers` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `activities` (`id`,`streamer_id`,`type`,`description`,`points`,`activity_date`,`evidence_url`,`created_by`,`created_at`) VALUES
('1','2','viral_video','Bonificação Staff: teste','50','2026-08-18',NULL,'1','2026-08-18 15:19:02'),
('2','2','viral_video','Bonificação Staff: teste','50','2026-08-18',NULL,'1','2026-08-18 15:21:31'),
('3','2','viral_video','Bonificação Staff: teste','50','2026-08-18',NULL,'1','2026-08-18 16:44:05');

DROP TABLE IF EXISTS `admin_commands`;
CREATE TABLE `admin_commands` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `command` varchar(100) NOT NULL,
  `description` varchar(500) NOT NULL,
  `position` int(11) NOT NULL DEFAULT 0,
  `active` tinyint(1) NOT NULL DEFAULT 1,
  `created_by` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `command` (`command`),
  KEY `fk_admin_commands_created_by` (`created_by`),
  CONSTRAINT `fk_admin_commands_created_by` FOREIGN KEY (`created_by`) REFERENCES `staff_users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `admin_commands` (`id`,`command`,`description`,`position`,`active`,`created_by`,`created_at`,`updated_at`) VALUES
('2','/tpm','Teleporta até a marcação do mapa.','1','1','1','2026-08-21 06:18:06','2026-08-21 06:41:13'),
('3','/cds','Mostra a CDS da localização atual.','2','1','1','2026-08-21 06:18:06','2026-08-21 06:44:46'),
('4','/nc','Ativa ou desativa o Noclip e Invisibilidade.','3','1','1','2026-08-21 06:18:06','2026-08-21 06:44:46'),
('5','/pedpainel','Painel de Peds (Acesso Restrito).','4','1','1','2026-08-21 06:18:06','2026-08-21 06:44:46'),
('6','/dv','Guarda a carroça ou veículo utilizado.','5','1','1','2026-08-21 06:18:06','2026-08-21 06:44:46'),
('7','/revive','Revive você mesmo.','6','1','1','2026-08-21 06:18:06','2026-08-21 06:44:46'),
('8','/revive iddbabota','Revive outro jogador utilizando o ID.','7','1','1','2026-08-21 06:18:06','2026-08-21 06:44:46'),
('9','/god','Enche fome, sede, vida e remove o stress.','8','1','1','2026-08-21 06:18:06','2026-08-21 06:44:46'),
('10','/god iddbabota','Enche fome, sede, vida e remove o stress de outro jogador.','9','1','1','2026-08-21 06:18:06','2026-08-21 06:44:46'),
('11','/tpto iddbabota','Teleporta você até o jogador informado.','10','1','1','2026-08-21 06:18:06','2026-08-21 06:44:46'),
('12','/tptome iddbabota','Teleporta o jogador informado até você.','11','1','1','2026-08-21 06:18:06','2026-08-21 06:44:46'),
('13','/crafadmin','Atualizar o Craft das Fazendas','12','1','1','2026-08-21 07:16:39','2026-08-21 07:16:39'),
('14','/setname id nome nome','Alterar o nome do personagem na cidade','13','1','1','2026-08-21 07:17:51','2026-08-21 07:17:51'),
('15','/herancaset idfixo','Setar manualmente uma herança','14','1','1','2026-08-21 07:18:36','2026-08-21 07:18:36'),
('16','/alterarcdsplayer','Comando para caso o player fique crashando em algum lugar','15','1','1','2026-08-21 07:19:04','2026-08-21 07:19:04'),
('17','/resetpersonagem idfixo','Mandar personagem pra criação / plástica','16','1','1','2026-08-21 07:19:56','2026-08-21 07:19:56'),
('21','/pedmenu','Menu de Ped do Condado','17','1','1','2026-08-21 12:20:35','2026-08-21 12:20:35');

DROP TABLE IF EXISTS `audit_logs`;
CREATE TABLE `audit_logs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `staff_id` int(10) unsigned DEFAULT NULL,
  `staff_name` varchar(150) NOT NULL,
  `affected_user_id` int(10) unsigned DEFAULT NULL,
  `affected_user_name` varchar(150) DEFAULT NULL,
  `action` varchar(80) NOT NULL,
  `category` varchar(60) NOT NULL,
  `details` text DEFAULT NULL,
  `before_data` longtext DEFAULT NULL,
  `after_data` longtext DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` varchar(500) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_audit_created` (`created_at`),
  KEY `idx_audit_user` (`affected_user_id`),
  KEY `idx_audit_staff` (`staff_id`),
  KEY `idx_audit_action` (`action`),
  KEY `idx_audit_category` (`category`)
) ENGINE=InnoDB AUTO_INCREMENT=88 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `audit_logs` (`id`,`staff_id`,`staff_name`,`affected_user_id`,`affected_user_name`,`action`,`category`,`details`,`before_data`,`after_data`,`ip_address`,`user_agent`,`created_at`) VALUES
('1','1','Mod Luci','4','Mákhawi','VOD aprovada','VOD','VOD aprovada pela Staff.','{\"status\":\"pending\",\"duration_minutes\":348}','{\"status\":\"approved\",\"duration_minutes\":348,\"points\":0}','177.148.141.4','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 OPR/134.0.0.0 (Edition std-2)','2026-08-20 17:49:38'),
('2','1','Mod Luci','4','Mákhawi','VOD aprovada','VOD','VOD aprovada pela Staff.','{\"status\":\"pending\",\"duration_minutes\":659}','{\"status\":\"approved\",\"duration_minutes\":660,\"points\":0}','177.148.141.4','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 OPR/134.0.0.0 (Edition std-2)','2026-08-20 17:50:24'),
('3','1','Mod Luci',NULL,'/painel2','Editou comando administrativo','Comandos Admin','Comando alterado','{\"id\":1,\"command\":\"/painel\",\"description\":\"Abre o Painel da Staff.\",\"position\":1,\"active\":1,\"created_by\":1,\"created_at\":\"2026-08-21 06:18:06\",\"updated_at\":\"2026-08-21 06:18:06\"}','{\"command\":\"/painel2\",\"description\":\"Abre o Painel da Staff.\",\"position\":1,\"active\":1}','177.148.215.156','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 OPR/134.0.0.0 (Edition std-2)','2026-08-21 06:29:55'),
('4','1','Mod Luci',NULL,'/painel2','Excluiu comando administrativo','Comandos Admin','Comando excluído','{\"id\":1,\"command\":\"/painel2\",\"description\":\"Abre o Painel da Staff.\",\"position\":1,\"active\":1,\"created_by\":1,\"created_at\":\"2026-08-21 06:18:06\",\"updated_at\":\"2026-08-21 06:29:54\"}',NULL,'177.148.215.156','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 OPR/134.0.0.0 (Edition std-2)','2026-08-21 06:41:05'),
('5','1','Mod Luci',NULL,'/tpm','Editou comando administrativo','Comandos Admin','Comando alterado','{\"id\":2,\"command\":\"/tpm\",\"description\":\"Teleporta até a marcação do mapa.\",\"position\":2,\"active\":1,\"created_by\":1,\"created_at\":\"2026-08-21 06:18:06\",\"updated_at\":\"2026-08-21 06:18:06\"}','{\"command\":\"/tpm\",\"description\":\"Teleporta até a marcação do mapa.\",\"position\":1,\"active\":1}','177.148.215.156','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 OPR/134.0.0.0 (Edition std-2)','2026-08-21 06:41:13'),
('6','1','Mod Luci',NULL,'/tpm','Editou comando administrativo','Comandos Admin','Comando alterado','{\"id\":2,\"command\":\"/tpm\",\"description\":\"Teleporta até a marcação do mapa.\",\"position\":1,\"active\":1,\"created_by\":1,\"created_at\":\"2026-08-21 06:18:06\",\"updated_at\":\"2026-08-21 06:41:13\"}','{\"command\":\"/tpm\",\"description\":\"Teleporta até a marcação do mapa.\",\"position\":1,\"active\":1}','177.148.215.156','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 OPR/134.0.0.0 (Edition std-2)','2026-08-21 06:41:13'),
('7','1','Mod Luci',NULL,'/tpm','Editou comando administrativo','Comandos Admin','Comando alterado','{\"id\":2,\"command\":\"/tpm\",\"description\":\"Teleporta até a marcação do mapa.\",\"position\":1,\"active\":1,\"created_by\":1,\"created_at\":\"2026-08-21 06:18:06\",\"updated_at\":\"2026-08-21 06:41:13\"}','{\"command\":\"/tpm\",\"description\":\"Teleporta até a marcação do mapa.\",\"position\":1,\"active\":1}','177.148.215.156','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 OPR/134.0.0.0 (Edition std-2)','2026-08-21 06:44:46'),
('8','1','Mod Luci',NULL,'/tpm','Editou comando administrativo','Comandos Admin','Comando alterado','{\"id\":2,\"command\":\"/tpm\",\"description\":\"Teleporta até a marcação do mapa.\",\"position\":1,\"active\":1,\"created_by\":1,\"created_at\":\"2026-08-21 06:18:06\",\"updated_at\":\"2026-08-21 06:41:13\"}','{\"command\":\"/tpm\",\"description\":\"Teleporta até a marcação do mapa.\",\"position\":1,\"active\":1}','177.148.215.156','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 OPR/134.0.0.0 (Edition std-2)','2026-08-21 06:44:52'),
('9','1','Mod Luci',NULL,'Coordenadas_Empresas_Nevada (1).txt','Importou coordenadas em lote','Comandos Admin','Importação de coordenadas TXT concluída',NULL,'{\"arquivo\":\"Coordenadas_Empresas_Nevada (1).txt\",\"importados\":39,\"ignorados\":0,\"erros\":0}','177.148.215.156','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 OPR/134.0.0.0 (Edition std-2)','2026-08-21 06:50:33'),
('10','1','Mod Luci',NULL,'Coordenadas_Empresas_Nevada (1).txt','Importou coordenadas em lote','Comandos Admin','Importação de coordenadas TXT concluída',NULL,'{\"arquivo\":\"Coordenadas_Empresas_Nevada (1).txt\",\"importados\":0,\"ignorados\":39,\"erros\":0}','177.148.215.156','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 OPR/134.0.0.0 (Edition std-2)','2026-08-21 07:10:18'),
('11','1','Mod Luci',NULL,'Identidade Staff','Alterou identidade da página de comandos','Comandos Admin','Cabeçalho da página atualizado','{\"id\":1,\"top_name\":\"NEVADA STAFF\",\"eyebrow_name\":\"NEVADA ROLEPLAY · STAFF\",\"updated_at\":\"2026-08-21 07:10:18\"}','{\"top_name\":\"NEVADA STAFF\",\"eyebrow_name\":\"NEVADA ROLEPLAY · STAFF\"}','177.148.215.156','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 OPR/134.0.0.0 (Edition std-2)','2026-08-21 07:10:52'),
('12','1','Mod Luci',NULL,'/crafadmin','Criou comando administrativo','Comandos Admin','Comando criado','{\"command\":null}','{\"command\":\"/crafadmin\",\"description\":\"Atualizar o Craft das Fazendas\",\"position\":12}','177.148.215.156','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 OPR/134.0.0.0 (Edition std-2)','2026-08-21 07:16:39'),
('13','1','Mod Luci',NULL,'/setname id nome nome','Criou comando administrativo','Comandos Admin','Comando criado','{\"command\":null}','{\"command\":\"/setname id nome nome\",\"description\":\"Alterar o nome do personagem na cidade\",\"position\":13}','177.148.215.156','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 OPR/134.0.0.0 (Edition std-2)','2026-08-21 07:17:51'),
('14','1','Mod Luci',NULL,'/herancaset idfixo','Criou comando administrativo','Comandos Admin','Comando criado','{\"command\":null}','{\"command\":\"/herancaset idfixo\",\"description\":\"Setar manualmente uma herança\",\"position\":14}','177.148.215.156','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 OPR/134.0.0.0 (Edition std-2)','2026-08-21 07:18:36'),
('15','1','Mod Luci',NULL,'/alterarcdsplayer','Criou comando administrativo','Comandos Admin','Comando criado','{\"command\":null}','{\"command\":\"/alterarcdsplayer\",\"description\":\"Comando para caso o player fique crashando em algum lugar\",\"position\":15}','177.148.215.156','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 OPR/134.0.0.0 (Edition std-2)','2026-08-21 07:19:04'),
('16','1','Mod Luci',NULL,'/resetpersonagem idfixo','Criou comando administrativo','Comandos Admin','Comando criado','{\"command\":null}','{\"command\":\"/resetpersonagem idfixo\",\"description\":\"Mandar personagem pra criação / plástica\",\"position\":16}','177.148.215.156','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 OPR/134.0.0.0 (Edition std-2)','2026-08-21 07:19:56'),
('17','1','Mod Luci',NULL,'/Comandos da Cavaleria','Criou comando administrativo','Comandos Admin','Comando criado','{\"command\":null}','{\"command\":\"/Comandos da Cavaleria\",\"description\":\"Algemar: Item handcuffs + comando /cuff (bloqueia controles)\\r\\nEscoltar: Comando /escoltar (anexa suspeito ao oficial)\\r\\nRevistar: Comando /revistar (abre inventário do suspeito)\\r\\nDistintivo: Comando /lawbadge (visual on-duty)\\r\\nPrender CAMPO: Comando /prender → abre formulário NUI com tempo (min) + motivo\\r\\nPainel Policial: /mdt\",\"position\":17}','177.148.215.156','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 OPR/134.0.0.0 (Edition std-2)','2026-08-21 07:21:48'),
('18','1','Mod Luci',NULL,'/Comandos da Cavaleria','Editou comando administrativo','Comandos Admin','Comando alterado','{\"id\":18,\"command\":\"/Comandos da Cavaleria\",\"description\":\"Algemar: Item handcuffs + comando /cuff (bloqueia controles)\\r\\nEscoltar: Comando /escoltar (anexa suspeito ao oficial)\\r\\nRevistar: Comando /revistar (abre inventário do suspeito)\\r\\nDistintivo: Comando /lawbadge (visual on-duty)\\r\\nPrender CAMPO: Comando /prender → abre formulário NUI com tempo (min) + motivo\\r\\nPainel Policial: /mdt\",\"position\":17,\"active\":1,\"created_by\":1,\"created_at\":\"2026-08-21 07:21:48\",\"updated_at\":\"2026-08-21 07:21:48\"}','{\"command\":\"/Comandos da Cavaleria\",\"description\":\"Algemar: /cuff\\r\\nEscoltar: /escoltar\\r\\nRevistar: /revistar\\r\\nDistintivo: /lawbadge\\r\\nPrender: /prender\\r\\nPainel Policial: /mdt\",\"position\":17,\"active\":1}','177.148.215.156','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 OPR/134.0.0.0 (Edition std-2)','2026-08-21 07:23:47'),
('19','1','Mod Luci',NULL,'Xerifado_Cavalaria_Nevada.txt','Importou coordenadas em lote','Comandos Admin','Importação de coordenadas TXT concluída',NULL,'{\"arquivo\":\"Xerifado_Cavalaria_Nevada.txt\",\"importados\":0,\"ignorados\":0,\"erros\":6}','177.148.215.156','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 OPR/134.0.0.0 (Edition std-2)','2026-08-21 07:26:30'),
('20','1','Mod Luci',NULL,'Xerifado_Cavalaria_Nevada.txt','Importou coordenadas em lote','Comandos Admin','Importação de coordenadas TXT concluída',NULL,'{\"arquivo\":\"Xerifado_Cavalaria_Nevada.txt\",\"importados\":6,\"ignorados\":0,\"erros\":0}','177.148.215.156','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 OPR/134.0.0.0 (Edition std-2)','2026-08-21 07:37:10'),
('21','1','Mod Luci',NULL,'Legal','Editou categoria de coordenadas','Comandos Admin','Categoria alterada','{\"id\":6,\"name\":\"Xerifado\",\"icon\":\"⭐\",\"active\":1,\"created_by\":1,\"created_at\":\"2026-08-21 07:37:10\",\"updated_at\":\"2026-08-21 07:37:10\"}','{\"name\":\"Legal\",\"icon\":\"⭐\"}','177.148.215.156','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 OPR/134.0.0.0 (Edition std-2)','2026-08-21 07:37:44'),
('22','1','Mod Luci',NULL,'Lobisomen','Criou subcategoria de coordenadas','Comandos Admin','Subcategoria criada',NULL,'{\"category\":\"Sobrenatural\",\"subcategory\":\"Lobisomen\"}','177.148.215.156','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 OPR/134.0.0.0 (Edition std-2)','2026-08-21 07:38:31'),
('23','1','Mod Luci',NULL,'Tru','Editou subcategoria de coordenadas','Comandos Admin','Subcategoria alterada','{\"id\":15,\"category_id\":6,\"name\":\"Geral\",\"active\":1,\"created_at\":\"2026-08-21 07:37:10\",\"updated_at\":\"2026-08-21 07:37:10\",\"category_name\":\"Legal\"}','{\"category\":\"Legal\",\"subcategory\":\"Tru\"}','177.148.215.156','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 OPR/134.0.0.0 (Edition std-2)','2026-08-21 07:38:46'),
('24','1','Mod Luci',NULL,'Tribunal','Editou subcategoria de coordenadas','Comandos Admin','Subcategoria alterada','{\"id\":15,\"category_id\":6,\"name\":\"Tru\",\"active\":1,\"created_at\":\"2026-08-21 07:37:10\",\"updated_at\":\"2026-08-21 07:38:46\",\"category_name\":\"Legal\"}','{\"category\":\"Legal\",\"subcategory\":\"Tribunal\"}','177.148.215.156','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 OPR/134.0.0.0 (Edition std-2)','2026-08-21 07:39:19'),
('25','1','Mod Luci',NULL,'Tribunal','Editou subcategoria de coordenadas','Comandos Admin','Subcategoria alterada','{\"id\":15,\"category_id\":6,\"name\":\"Tribunal\",\"active\":1,\"created_at\":\"2026-08-21 07:37:10\",\"updated_at\":\"2026-08-21 07:39:19\",\"category_name\":\"Legal\"}','{\"category\":\"Legal\",\"subcategory\":\"Tribunal\"}','177.148.215.156','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 OPR/134.0.0.0 (Edition std-2)','2026-08-21 07:42:02'),
('26','1','Mod Luci',NULL,'Tribunal','Editou subcategoria de coordenadas','Comandos Admin','Subcategoria alterada','{\"id\":15,\"category_id\":6,\"name\":\"Tribunal\",\"active\":1,\"created_at\":\"2026-08-21 07:37:10\",\"updated_at\":\"2026-08-21 07:39:19\",\"category_name\":\"Legal\"}','{\"category\":\"Legal\",\"subcategory\":\"Tribunal\"}','177.148.215.156','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 OPR/134.0.0.0 (Edition std-2)','2026-08-21 07:42:10'),
('27','1','Mod Luci',NULL,'Tribunal','Editou subcategoria de coordenadas','Comandos Admin','Subcategoria alterada','{\"id\":15,\"category_id\":6,\"name\":\"Tribunal\",\"active\":1,\"created_at\":\"2026-08-21 07:37:10\",\"updated_at\":\"2026-08-21 07:39:19\",\"category_name\":\"Legal\"}','{\"category\":\"Legal\",\"subcategory\":\"Tribunal\"}','177.148.215.156','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 OPR/134.0.0.0 (Edition std-2)','2026-08-21 07:45:55'),
('28','1','Mod Luci',NULL,'Bandoleiro','Editou categoria de coordenadas','Comandos Admin','Categoria alterada','{\"id\":4,\"name\":\"Grupos\",\"icon\":\"👥\",\"active\":1,\"created_by\":1,\"created_at\":\"2026-08-21 07:37:10\",\"updated_at\":\"2026-08-21 07:37:10\"}','{\"name\":\"Bandoleiro\",\"icon\":\"👥\"}','177.148.215.156','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 OPR/134.0.0.0 (Edition std-2)','2026-08-21 07:47:18'),
('29','1','Mod Luci',NULL,'Hospital','Criou subcategoria de coordenadas','Comandos Admin','Subcategoria criada',NULL,'{\"category\":\"Legal\",\"subcategory\":\"Hospital\"}','177.148.215.156','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 OPR/134.0.0.0 (Edition std-2)','2026-08-21 07:49:10'),
('30','1','Mod Luci',NULL,'Sobrenatural','Editou categoria de coordenadas','Comandos Admin','Categoria alterada','{\"id\":5,\"name\":\"Sobrenatural\",\"icon\":\"👻\",\"active\":1,\"created_by\":1,\"created_at\":\"2026-08-21 07:37:10\",\"updated_at\":\"2026-08-21 07:37:10\"}','{\"name\":\"Sobrenatural\",\"icon\":\"👻\"}','177.148.215.156','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 OPR/134.0.0.0 (Edition std-2)','2026-08-21 07:49:29'),
('31','1','Mod Luci',NULL,'Armarias','Editou subcategoria de coordenadas','Comandos Admin','Subcategoria alterada','{\"id\":5,\"category_id\":1,\"name\":\"Armarias\",\"active\":1,\"created_at\":\"2026-08-21 07:37:10\",\"updated_at\":\"2026-08-21 07:37:10\",\"category_name\":\"Empresas\"}','{\"category\":\"Empresas\",\"subcategory\":\"Armarias\"}','177.148.215.156','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 OPR/134.0.0.0 (Edition std-2)','2026-08-21 07:51:33'),
('32','1','Mod Luci',NULL,'Armarias','Editou subcategoria de coordenadas','Comandos Admin','Subcategoria alterada','{\"id\":5,\"category_id\":1,\"name\":\"Armarias\",\"active\":1,\"created_at\":\"2026-08-21 07:37:10\",\"updated_at\":\"2026-08-21 07:37:10\",\"category_name\":\"Empresas\"}','{\"category\":\"Empresas\",\"subcategory\":\"Armarias\"}','177.148.215.156','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 OPR/134.0.0.0 (Edition std-2)','2026-08-21 07:51:51'),
('33','1','Mod Luci',NULL,'Xerifado','Excluiu categoria de coordenadas','Comandos Admin','Categoria excluída','{\"id\":18,\"name\":\"Xerifado\",\"icon\":\"⭐\",\"active\":1,\"created_by\":1,\"created_at\":\"2026-08-21 07:38:31\",\"updated_at\":\"2026-08-21 07:38:31\"}',NULL,'177.148.215.156','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 OPR/134.0.0.0 (Edition std-2)','2026-08-21 07:52:42'),
('34','1','Mod Luci',NULL,'Xerifado','Excluiu categoria de coordenadas','Comandos Admin','Categoria excluída','{\"id\":204,\"name\":\"Xerifado\",\"icon\":\"⭐\",\"active\":1,\"created_by\":1,\"created_at\":\"2026-08-21 07:52:42\",\"updated_at\":\"2026-08-21 07:52:42\"}',NULL,'177.148.215.156','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 OPR/134.0.0.0 (Edition std-2)','2026-08-21 07:53:11'),
('35','1','Mod Luci',NULL,'Xerifado','Excluiu categoria de coordenadas','Comandos Admin','Categoria, subcategorias e coordenadas vinculadas excluídas','{\"id\":216,\"name\":\"Xerifado\",\"icon\":\"⭐\",\"active\":1,\"created_by\":1,\"created_at\":\"2026-08-21 07:53:11\",\"updated_at\":\"2026-08-21 07:53:11\"}',NULL,'177.148.215.156','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 OPR/134.0.0.0 (Edition std-2)','2026-08-21 07:54:55'),
('36','1','Mod Luci',NULL,'Xerifado_Cavalaria_Nevada.txt','Importou coordenadas em lote','Comandos Admin','Importação de coordenadas TXT concluída',NULL,'{\"arquivo\":\"Xerifado_Cavalaria_Nevada.txt\",\"importados\":0,\"ignorados\":6,\"erros\":0}','177.148.215.156','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 OPR/134.0.0.0 (Edition std-2)','2026-08-21 07:56:05'),
('37','1','Mod Luci',NULL,'Sobrenatural','Editou categoria de coordenadas','Comandos Admin','Categoria alterada','{\"id\":5,\"name\":\"Sobrenatural\",\"icon\":\"👻\",\"active\":1,\"created_by\":1,\"created_at\":\"2026-08-21 07:37:10\",\"updated_at\":\"2026-08-21 07:37:10\"}','{\"name\":\"Sobrenatural\",\"icon\":\"👻\"}','177.148.215.156','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 OPR/134.0.0.0 (Edition std-2)','2026-08-21 08:03:28'),
('38','1','Mod Luci',NULL,'Bandoleiro 1','Editou subcategoria de coordenadas','Comandos Admin','Subcategoria alterada em lote','{\"id\":12,\"category_id\":4,\"name\":\"Geral\",\"icon\":\"📍\",\"active\":1,\"created_at\":\"2026-08-21 07:37:10\",\"updated_at\":\"2026-08-21 07:37:10\",\"category_name\":\"Bandoleiro\"}','{\"category\":\"Bandoleiro\",\"subcategory\":\"Bandoleiro 1\",\"icon\":\"💀\"}','177.148.215.156','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 OPR/134.0.0.0 (Edition std-2)','2026-08-21 08:18:21'),
('39','1','Mod Luci',NULL,'Casa','Editou subcategoria de coordenadas','Comandos Admin','Subcategoria alterada em lote','{\"id\":11,\"category_id\":3,\"name\":\"Geral\",\"icon\":\"📍\",\"active\":1,\"created_at\":\"2026-08-21 07:37:10\",\"updated_at\":\"2026-08-21 07:37:10\",\"category_name\":\"Casas\"}','{\"category\":\"Casas\",\"subcategory\":\"Casa\",\"icon\":\"🏠\"}','177.148.215.156','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 OPR/134.0.0.0 (Edition std-2)','2026-08-21 08:18:21'),
('40','1','Mod Luci',NULL,'Armarias','Editou subcategoria de coordenadas','Comandos Admin','Subcategoria alterada em lote','{\"id\":5,\"category_id\":1,\"name\":\"Armarias\",\"icon\":\"📍\",\"active\":1,\"created_at\":\"2026-08-21 07:37:10\",\"updated_at\":\"2026-08-21 07:37:10\",\"category_name\":\"Empresas\"}','{\"category\":\"Empresas\",\"subcategory\":\"Armarias\",\"icon\":\"🔫\"}','177.148.215.156','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 OPR/134.0.0.0 (Edition std-2)','2026-08-21 08:18:21'),
('41','1','Mod Luci',NULL,'Artesanatos','Editou subcategoria de coordenadas','Comandos Admin','Subcategoria alterada em lote','{\"id\":4,\"category_id\":1,\"name\":\"Artesanatos\",\"icon\":\"📍\",\"active\":1,\"created_at\":\"2026-08-21 07:37:10\",\"updated_at\":\"2026-08-21 07:37:10\",\"category_name\":\"Empresas\"}','{\"category\":\"Empresas\",\"subcategory\":\"Artesanatos\",\"icon\":\"🎭\"}','177.148.215.156','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 OPR/134.0.0.0 (Edition std-2)','2026-08-21 08:18:21'),
('42','1','Mod Luci',NULL,'Ateliês','Editou subcategoria de coordenadas','Comandos Admin','Subcategoria alterada em lote','{\"id\":6,\"category_id\":1,\"name\":\"Ateliês\",\"icon\":\"📍\",\"active\":1,\"created_at\":\"2026-08-21 07:37:10\",\"updated_at\":\"2026-08-21 07:37:10\",\"category_name\":\"Empresas\"}','{\"category\":\"Empresas\",\"subcategory\":\"Ateliês\",\"icon\":\"🎀\"}','177.148.215.156','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 OPR/134.0.0.0 (Edition std-2)','2026-08-21 08:18:21'),
('43','1','Mod Luci',NULL,'Ferrarias','Editou subcategoria de coordenadas','Comandos Admin','Subcategoria alterada em lote','{\"id\":2,\"category_id\":1,\"name\":\"Ferrarias\",\"icon\":\"📍\",\"active\":1,\"created_at\":\"2026-08-21 07:37:10\",\"updated_at\":\"2026-08-21 07:37:10\",\"category_name\":\"Empresas\"}','{\"category\":\"Empresas\",\"subcategory\":\"Ferrarias\",\"icon\":\"🔨\"}','177.148.215.156','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 OPR/134.0.0.0 (Edition std-2)','2026-08-21 08:18:21'),
('44','1','Mod Luci',NULL,'Jornais','Editou subcategoria de coordenadas','Comandos Admin','Subcategoria alterada em lote','{\"id\":8,\"category_id\":1,\"name\":\"Jornais\",\"icon\":\"📍\",\"active\":1,\"created_at\":\"2026-08-21 07:37:10\",\"updated_at\":\"2026-08-21 07:37:10\",\"category_name\":\"Empresas\"}','{\"category\":\"Empresas\",\"subcategory\":\"Jornais\",\"icon\":\"📄\"}','177.148.215.156','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 OPR/134.0.0.0 (Edition std-2)','2026-08-21 08:18:21'),
('45','1','Mod Luci',NULL,'Perfumarias','Editou subcategoria de coordenadas','Comandos Admin','Subcategoria alterada em lote','{\"id\":7,\"category_id\":1,\"name\":\"Perfumarias\",\"icon\":\"📍\",\"active\":1,\"created_at\":\"2026-08-21 07:37:10\",\"updated_at\":\"2026-08-21 07:37:10\",\"category_name\":\"Empresas\"}','{\"category\":\"Empresas\",\"subcategory\":\"Perfumarias\",\"icon\":\"🌸\"}','177.148.215.156','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 OPR/134.0.0.0 (Edition std-2)','2026-08-21 08:18:21'),
('46','1','Mod Luci',NULL,'Saloons','Editou subcategoria de coordenadas','Comandos Admin','Subcategoria alterada em lote','{\"id\":1,\"category_id\":1,\"name\":\"Saloons\",\"icon\":\"📍\",\"active\":1,\"created_at\":\"2026-08-21 07:37:10\",\"updated_at\":\"2026-08-21 07:37:10\",\"category_name\":\"Empresas\"}','{\"category\":\"Empresas\",\"subcategory\":\"Saloons\",\"icon\":\"🥧\"}','177.148.215.156','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 OPR/134.0.0.0 (Edition std-2)','2026-08-21 08:18:21'),
('47','1','Mod Luci',NULL,'Tabacarias','Editou subcategoria de coordenadas','Comandos Admin','Subcategoria alterada em lote','{\"id\":3,\"category_id\":1,\"name\":\"Tabacarias\",\"icon\":\"📍\",\"active\":1,\"created_at\":\"2026-08-21 07:37:10\",\"updated_at\":\"2026-08-21 07:37:10\",\"category_name\":\"Empresas\"}','{\"category\":\"Empresas\",\"subcategory\":\"Tabacarias\",\"icon\":\"🚬\"}','177.148.215.156','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 OPR/134.0.0.0 (Edition std-2)','2026-08-21 08:18:21'),
('48','1','Mod Luci',NULL,'Cavalaria','Editou subcategoria de coordenadas','Comandos Admin','Subcategoria alterada em lote','{\"id\":14,\"category_id\":6,\"name\":\"Cavalaria\",\"icon\":\"📍\",\"active\":1,\"created_at\":\"2026-08-21 07:37:10\",\"updated_at\":\"2026-08-21 07:37:10\",\"category_name\":\"Legal\"}','{\"category\":\"Legal\",\"subcategory\":\"Cavalaria\",\"icon\":\"⭐\"}','177.148.215.156','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 OPR/134.0.0.0 (Edition std-2)','2026-08-21 08:18:21'),
('49','1','Mod Luci',NULL,'Hospital','Editou subcategoria de coordenadas','Comandos Admin','Subcategoria alterada em lote','{\"id\":347,\"category_id\":6,\"name\":\"Hospital\",\"icon\":\"📍\",\"active\":1,\"created_at\":\"2026-08-21 07:49:10\",\"updated_at\":\"2026-08-21 07:49:10\",\"category_name\":\"Legal\"}','{\"category\":\"Legal\",\"subcategory\":\"Hospital\",\"icon\":\"💉\"}','177.148.215.156','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 OPR/134.0.0.0 (Edition std-2)','2026-08-21 08:18:21'),
('50','1','Mod Luci',NULL,'Tribunal','Editou subcategoria de coordenadas','Comandos Admin','Subcategoria alterada em lote','{\"id\":15,\"category_id\":6,\"name\":\"Tribunal\",\"icon\":\"📍\",\"active\":1,\"created_at\":\"2026-08-21 07:37:10\",\"updated_at\":\"2026-08-21 07:39:19\",\"category_name\":\"Legal\"}','{\"category\":\"Legal\",\"subcategory\":\"Tribunal\",\"icon\":\"💼\"}','177.148.215.156','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 OPR/134.0.0.0 (Edition std-2)','2026-08-21 08:18:22'),
('51','1','Mod Luci',NULL,'Bruxa','Editou subcategoria de coordenadas','Comandos Admin','Subcategoria alterada em lote','{\"id\":13,\"category_id\":5,\"name\":\"Geral\",\"icon\":\"📍\",\"active\":1,\"created_at\":\"2026-08-21 07:37:10\",\"updated_at\":\"2026-08-21 07:37:10\",\"category_name\":\"Sobrenatural\"}','{\"category\":\"Sobrenatural\",\"subcategory\":\"Bruxa\",\"icon\":\"🧙‍♂️\"}','177.148.215.156','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 OPR/134.0.0.0 (Edition std-2)','2026-08-21 08:18:22'),
('52','1','Mod Luci',NULL,'Lobisomen','Editou subcategoria de coordenadas','Comandos Admin','Subcategoria alterada em lote','{\"id\":46,\"category_id\":5,\"name\":\"Lobisomen\",\"icon\":\"📍\",\"active\":1,\"created_at\":\"2026-08-21 07:38:31\",\"updated_at\":\"2026-08-21 07:38:31\",\"category_name\":\"Sobrenatural\"}','{\"category\":\"Sobrenatural\",\"subcategory\":\"Lobisomen\",\"icon\":\"🧔\"}','177.148.215.156','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 OPR/134.0.0.0 (Edition std-2)','2026-08-21 08:18:22'),
('53','1','Mod Luci',NULL,'Xerifado','Excluiu categoria de coordenadas','Comandos Admin','Categoria excluída','{\"id\":234,\"name\":\"Xerifado\",\"icon\":\"⭐\",\"active\":1,\"created_by\":1,\"created_at\":\"2026-08-21 07:54:55\",\"updated_at\":\"2026-08-21 07:54:55\"}',NULL,'177.148.215.156','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 OPR/134.0.0.0 (Edition std-2)','2026-08-21 08:26:17'),
('54','1','Mod Luci',NULL,'Xerifado','Excluiu categoria de coordenadas','Comandos Admin','Categoria excluída','{\"id\":312,\"name\":\"Xerifado\",\"icon\":\"⭐\",\"active\":1,\"created_by\":null,\"created_at\":\"2026-08-21 08:26:22\",\"updated_at\":\"2026-08-21 08:26:22\"}',NULL,'177.148.215.156','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 OPR/134.0.0.0 (Edition std-2)','2026-08-21 08:28:22'),
('55','1','Mod Luci',NULL,'Xerifado','Excluiu categoria de coordenadas','Comandos Admin','Categoria excluída','{\"id\":342,\"name\":\"Xerifado\",\"icon\":\"⭐\",\"active\":1,\"created_by\":1,\"created_at\":\"2026-08-21 08:28:25\",\"updated_at\":\"2026-08-21 08:28:25\"}',NULL,'177.148.215.156','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 OPR/134.0.0.0 (Edition std-2)','2026-08-21 08:30:26'),
('56','1','Mod Luci',NULL,'/painel referente aos medicos','Criou comando administrativo','Comandos Admin','Comando criado','{\"command\":null}','{\"command\":\"/painel referente aos medicos\",\"description\":\"Referente aos medicos do condado\",\"position\":18}','177.148.215.156','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 OPR/134.0.0.0 (Edition std-2)','2026-08-21 09:04:19'),
('57','1','Mod Luci',NULL,'painel médico','Criou comando de player','Comandos Players','Comando criado',NULL,'{\"name\":\"painel médico\",\"command\":\"/painel\",\"description\":\"Abre o Menu de painel médico\",\"position\":2}','177.148.215.156','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 OPR/134.0.0.0 (Edition std-2)','2026-08-21 11:45:09'),
('58','1','Mod Luci',NULL,'Algemar','Excluiu comando de player','Comandos Players','Comando excluído','{\"id\":1,\"name\":\"Algemar\",\"command\":\"/cuff\",\"description\":\"Comando utilizado pela Cavalaria para algemar outro jogador.\",\"position\":1,\"active\":1,\"created_by\":null,\"created_at\":\"2026-08-21 11:38:23\",\"updated_at\":\"2026-08-21 11:38:23\"}',NULL,'177.148.215.156','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 OPR/134.0.0.0 (Edition std-2)','2026-08-21 11:45:22'),
('59','1','Mod Luci',NULL,'Algemar','Criou comando de player','Comandos Players','Comando criado',NULL,'{\"name\":\"Algemar\",\"command\":\"/cuff\",\"description\":\"Comando utilizado pela Cavalaria para algemar outro jogador.\",\"position\":2}','177.148.215.156','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 OPR/134.0.0.0 (Edition std-2)','2026-08-21 11:45:38'),
('60','1','Mod Luci',NULL,'Escoltar','Criou comando de player','Comandos Players','Comando criado',NULL,'{\"name\":\"Escoltar\",\"command\":\"/escoltar\",\"description\":\"Escolta de uso da Cavalaria\",\"position\":3}','177.148.215.156','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 OPR/134.0.0.0 (Edition std-2)','2026-08-21 11:46:21'),
('61','1','Mod Luci',NULL,'Revistar','Criou comando de player','Comandos Players','Comando criado',NULL,'{\"name\":\"Revistar\",\"command\":\"/revistar\",\"description\":\"Revista usado da Cavalaria\",\"position\":4}','177.148.215.156','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 OPR/134.0.0.0 (Edition std-2)','2026-08-21 11:46:49'),
('62','1','Mod Luci',NULL,'Distintivo','Criou comando de player','Comandos Players','Comando criado',NULL,'{\"name\":\"Distintivo\",\"command\":\"/lawbadge\",\"description\":\"Ajuste distintivo da Cavalaria\",\"position\":5}','177.148.215.156','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 OPR/134.0.0.0 (Edition std-2)','2026-08-21 11:47:25'),
('63','1','Mod Luci',NULL,'Prender','Criou comando de player','Comandos Players','Comando criado',NULL,'{\"name\":\"Prender\",\"command\":\"/prender\",\"description\":\"Abrir menu de Prisão da Cavalaria\",\"position\":6}','177.148.215.156','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 OPR/134.0.0.0 (Edition std-2)','2026-08-21 11:48:19'),
('64','1','Mod Luci',NULL,'Painel Policial','Criou comando de player','Comandos Players','Comando criado',NULL,'{\"name\":\"Painel Policial\",\"command\":\"/mdt\",\"description\":\"Painel Policial\",\"position\":7}','177.148.215.156','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 OPR/134.0.0.0 (Edition std-2)','2026-08-21 11:48:46'),
('65','1','Mod Luci',NULL,'Verificar Documento','Criou comando de player','Comandos Players','Comando criado',NULL,'{\"name\":\"Verificar Documento\",\"command\":\"/pid\",\"description\":\"Cavalaria verifica documentação\",\"position\":8}','177.148.215.156','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 OPR/134.0.0.0 (Edition std-2)','2026-08-21 12:11:26'),
('66','1','Mod Luci',NULL,'Revistar Carroça','Criou comando de player','Comandos Players','Comando criado',NULL,'{\"name\":\"Revistar Carroça\",\"command\":\"/vercarroca\",\"description\":\"Revistar Carroça\",\"position\":9}','177.148.215.156','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 OPR/134.0.0.0 (Edition std-2)','2026-08-21 12:12:04'),
('67','1','Mod Luci',NULL,'Chamar Carroça','Criou comando de player','Comandos Players','Comando criado',NULL,'{\"name\":\"Chamar Carroça\",\"command\":\"/chamarcarroca\",\"description\":\"Opção de Chamar Carroça\",\"position\":10}','177.148.215.156','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 OPR/134.0.0.0 (Edition std-2)','2026-08-21 12:12:46'),
('68','1','Mod Luci',NULL,'Levantar Mangas','Criou comando de player','Comandos Players','Comando criado',NULL,'{\"name\":\"Levantar Mangas\",\"command\":\"/sleeve\",\"description\":\"Levantar mangas das camisas\",\"position\":11}','177.148.215.156','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 OPR/134.0.0.0 (Edition std-2)','2026-08-21 12:14:27'),
('69','1','Mod Luci',NULL,'Guardar Carroça','Criou comando de player','Comandos Players','Comando criado',NULL,'{\"name\":\"Guardar Carroça\",\"command\":\"/gc\",\"description\":\"Guarda a Carroça\",\"position\":12}','177.148.215.156','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 OPR/134.0.0.0 (Edition std-2)','2026-08-21 12:15:14'),
('70','1','Mod Luci',NULL,'Animações','Criou comando de player','Comandos Players','Comando criado',NULL,'{\"name\":\"Animações\",\"command\":\"/animacao\",\"description\":\"Menu de Animação\",\"position\":13}','177.148.215.156','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 OPR/134.0.0.0 (Edition std-2)','2026-08-21 12:16:21'),
('71','1','Mod Luci',NULL,'Anuncio','Criou comando de player','Comandos Players','Comando criado',NULL,'{\"name\":\"Anuncio\",\"command\":\"/anuncio\",\"description\":\"Para Médicos, Cavalaria, Prefeitura e Maquinista\",\"position\":14}','177.148.215.156','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 OPR/134.0.0.0 (Edition std-2)','2026-08-21 12:17:45'),
('72','1','Mod Luci',NULL,'Inspecao','Criou comando de player','Comandos Players','Comando criado',NULL,'{\"name\":\"Inspecao\",\"command\":\"/inspecao\",\"description\":\"Inspecionar a arma\",\"position\":15}','177.148.215.156','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 OPR/134.0.0.0 (Edition std-2)','2026-08-21 12:18:13'),
('73','1','Mod Luci',NULL,'/painel referente aos medicos','Excluiu comando administrativo','Comandos Admin','Comando excluído','{\"id\":19,\"command\":\"/painel referente aos medicos\",\"description\":\"Referente aos medicos do condado\",\"position\":18,\"active\":1,\"created_by\":1,\"created_at\":\"2026-08-21 09:04:19\",\"updated_at\":\"2026-08-21 09:04:19\"}',NULL,'177.148.215.156','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 OPR/134.0.0.0 (Edition std-2)','2026-08-21 12:19:59'),
('74','1','Mod Luci',NULL,'/Comandos da Cavaleria','Excluiu comando administrativo','Comandos Admin','Comando excluído','{\"id\":18,\"command\":\"/Comandos da Cavaleria\",\"description\":\"Algemar: /cuff\\r\\nEscoltar: /escoltar\\r\\nRevistar: /revistar\\r\\nDistintivo: /lawbadge\\r\\nPrender: /prender\\r\\nPainel Policial: /mdt\",\"position\":17,\"active\":1,\"created_by\":1,\"created_at\":\"2026-08-21 07:21:48\",\"updated_at\":\"2026-08-21 07:23:47\"}',NULL,'177.148.215.156','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 OPR/134.0.0.0 (Edition std-2)','2026-08-21 12:20:08'),
('75','1','Mod Luci',NULL,'/pedmenu','Criou comando administrativo','Comandos Admin','Comando criado','{\"command\":null}','{\"command\":\"/pedmenu\",\"description\":\"Menu de Ped do Condado\",\"position\":17}','177.148.215.156','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 OPR/134.0.0.0 (Edition std-2)','2026-08-21 12:20:35'),
('76','1','Mod Luci',NULL,'Logo','Alterou logo da página de comandos de players','Comandos Players','Logo pública atualizada',NULL,'{\"path\":\"assets/uploads/players_public/logo_20260821160030_d27a278a.png\"}','177.148.215.156','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 OPR/134.0.0.0 (Edition std-2)','2026-08-21 13:00:31'),
('77','1','Mod Luci',NULL,'Logo','Alterou logo da página de comandos de players','Comandos Players','Logo pública atualizada',NULL,'{\"path\":\"assets/uploads/players_public/logo_20260821160732_837b7d51.png\"}','177.148.215.156','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 OPR/134.0.0.0 (Edition std-2)','2026-08-21 13:07:32'),
('78','1','Mod Luci',NULL,'Background','Alterou background da página de comandos de players','Comandos Players','Background público atualizado',NULL,'{\"path\":\"assets/uploads/players_public/background_20260821160741_fa05fe92.png\"}','177.148.215.156','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 OPR/134.0.0.0 (Edition std-2)','2026-08-21 13:07:41'),
('79','1','Mod Luci',NULL,'Background','Alterou background da página de comandos de players','Comandos Players','Background público atualizado',NULL,'{\"path\":\"assets/uploads/players_public/background_20260821161206_3b3a0d05.webp\"}','177.148.215.156','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 OPR/134.0.0.0 (Edition std-2)','2026-08-21 13:12:06'),
('80','1','Mod Luci',NULL,'Logo','Alterou logo da página de comandos de players','Comandos Players','Logo pública atualizada',NULL,'{\"path\":\"assets/uploads/players_public/logo_20260821161217_2cd4183b.webp\"}','177.148.215.156','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 OPR/134.0.0.0 (Edition std-2)','2026-08-21 13:12:18'),
('81','1','Mod Luci',NULL,'Background','Alterou background da página de comandos de players','Comandos Players','Background público atualizado',NULL,'{\"path\":\"assets/uploads/players_public/background_20260821161224_cd92924a.webp\"}','177.148.215.156','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 OPR/134.0.0.0 (Edition std-2)','2026-08-21 13:12:25'),
('82','1','Mod Luci',NULL,'painel médico','Desativou comando de player','Comandos Players','Status alterado','{\"active\":1}','{\"active\":0}','177.148.215.156','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 OPR/134.0.0.0 (Edition std-2)','2026-08-21 13:14:55'),
('83','1','Mod Luci',NULL,'painel médico','Ativou comando de player','Comandos Players','Status alterado','{\"active\":0}','{\"active\":1}','177.148.215.156','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 OPR/134.0.0.0 (Edition std-2)','2026-08-21 13:15:05'),
('84','1','Mod Luci',NULL,'painel médico','Excluiu comando de player','Comandos Players','Comando excluído','{\"id\":2,\"name\":\"painel médico\",\"command\":\"/painel\",\"description\":\"Abre o menu principal do painel médico para acessar as ferramentas e funções disponíveis aos médicos.\",\"position\":1,\"active\":1,\"created_by\":1,\"created_at\":\"2026-08-21 11:45:09\",\"updated_at\":\"2026-08-21 13:15:05\"}',NULL,'177.148.215.156','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 OPR/134.0.0.0 (Edition std-2)','2026-08-21 13:16:08'),
('85','1','Mod Luci',NULL,'Painel Médico','Criou comando de player','Comandos Players','Comando criado',NULL,'{\"name\":\"Painel Médico\",\"command\":\"/painel\",\"description\":\"Abre o menu principal do painel médico para acessar as ferramentas e funções disponíveis aos médicos.\",\"position\":15}','177.148.215.156','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 OPR/134.0.0.0 (Edition std-2)','2026-08-21 13:16:20'),
('86','1','Mod Luci',NULL,'Background','Alterou background da página de comandos de players','Comandos Players','Background público atualizado',NULL,'{\"path\":\"assets/uploads/players_public/background_20260821161956_3ab70cb1.webp\"}','177.148.215.156','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 OPR/134.0.0.0 (Edition std-2)','2026-08-21 13:19:57'),
('87','1','Mod Luci',NULL,'Logo','Alterou logo da página de comandos de players','Comandos Players','Logo pública atualizada',NULL,'{\"path\":\"assets/uploads/players_public/logo_20260821162009_24001798.webp\"}','177.148.215.156','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 OPR/134.0.0.0 (Edition std-2)','2026-08-21 13:20:10');

DROP TABLE IF EXISTS `content_submission_images`;
CREATE TABLE `content_submission_images` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `submission_id` bigint(20) unsigned NOT NULL,
  `file_path` varchar(500) NOT NULL,
  `original_name` varchar(255) NOT NULL,
  `mime_type` varchar(100) NOT NULL,
  `file_size` int(10) unsigned NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_submission_images_submission` (`submission_id`),
  CONSTRAINT `content_submission_images_ibfk_1` FOREIGN KEY (`submission_id`) REFERENCES `content_submissions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


DROP TABLE IF EXISTS `content_submissions`;
CREATE TABLE `content_submissions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `streamer_id` int(10) unsigned NOT NULL,
  `content_type` varchar(40) NOT NULL,
  `url` varchar(700) NOT NULL,
  `submission_date` date NOT NULL,
  `collab` tinyint(1) NOT NULL DEFAULT 0,
  `collab_streamer_id` int(10) unsigned DEFAULT NULL,
  `status` enum('pending','approved','rejected') NOT NULL DEFAULT 'pending',
  `vod_id` bigint(20) unsigned DEFAULT NULL,
  `duration_minutes` int(10) unsigned DEFAULT NULL,
  `points_awarded` int(11) NOT NULL DEFAULT 0,
  `staff_notes` text DEFAULT NULL,
  `reviewed_by` int(10) unsigned DEFAULT NULL,
  `reviewed_at` datetime DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_submission_streamer_status` (`streamer_id`,`status`),
  KEY `idx_submission_date` (`streamer_id`,`submission_date`),
  KEY `collab_streamer_id` (`collab_streamer_id`),
  KEY `reviewed_by` (`reviewed_by`),
  KEY `vod_id` (`vod_id`),
  CONSTRAINT `content_submissions_ibfk_1` FOREIGN KEY (`streamer_id`) REFERENCES `streamers` (`id`) ON DELETE CASCADE,
  CONSTRAINT `content_submissions_ibfk_2` FOREIGN KEY (`collab_streamer_id`) REFERENCES `streamers` (`id`) ON DELETE SET NULL,
  CONSTRAINT `content_submissions_ibfk_3` FOREIGN KEY (`reviewed_by`) REFERENCES `staff_users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `content_submissions_ibfk_4` FOREIGN KEY (`vod_id`) REFERENCES `vods` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `content_submissions` (`id`,`streamer_id`,`content_type`,`url`,`submission_date`,`collab`,`collab_streamer_id`,`status`,`vod_id`,`duration_minutes`,`points_awarded`,`staff_notes`,`reviewed_by`,`reviewed_at`,`created_at`,`updated_at`) VALUES
('8','2','vod','https://www.twitch.tv/videos/2837067903','2026-08-04','0',NULL,'approved','9','42','0','','1','2026-08-18 13:32:25','2026-08-18 13:26:34','2026-08-18 13:32:25'),
('9','2','vod','https://www.twitch.tv/videos/2837373347','2026-08-04','0',NULL,'approved','8','41','0','','1','2026-08-18 13:32:07','2026-08-18 13:26:52','2026-08-18 13:32:07'),
('10','2','vod','https://www.twitch.tv/videos/2838216325','2026-08-05','0',NULL,'approved','7','113','0','','1','2026-08-18 13:31:42','2026-08-18 13:27:09','2026-08-18 13:31:42'),
('11','2','vod','https://www.twitch.tv/videos/2839626392','2026-08-07','0',NULL,'approved','6','39','0','','1','2026-08-18 13:31:20','2026-08-18 13:27:25','2026-08-18 13:31:20'),
('12','2','vod','https://www.twitch.tv/videos/2839988593','2026-08-07','0',NULL,'approved','5','32','0','','1','2026-08-18 13:30:56','2026-08-18 13:27:39','2026-08-18 13:30:56'),
('13','2','vod','https://www.twitch.tv/videos/2840014855','2026-08-07','0',NULL,'approved','4','119','0','','1','2026-08-18 13:30:31','2026-08-18 13:27:56','2026-08-18 13:30:31'),
('14','2','vod','https://www.twitch.tv/videos/2840590620','2026-08-08','0',NULL,'approved','3','57','0','','1','2026-08-18 13:30:06','2026-08-18 13:28:09','2026-08-18 13:30:06'),
('15','2','vod','https://www.twitch.tv/videos/2841608682','2026-08-09','0',NULL,'approved','2','52','0','','1','2026-08-18 13:29:44','2026-08-18 13:28:21','2026-08-18 13:29:44'),
('16','2','vod','https://www.twitch.tv/videos/2841752312','2026-08-09','0',NULL,'approved','1','46','0','','1','2026-08-18 13:29:19','2026-08-18 13:28:35','2026-08-18 13:29:19'),
('26','2','vod','https://www.twitch.tv/videos/284175231295','2026-08-18','0',NULL,'rejected',NULL,NULL,'0','','1','2026-08-18 16:53:24','2026-08-18 16:02:00','2026-08-18 16:53:24'),
('27','3','vod','https://www.twitch.tv/videos/2848380325','2026-08-16','0',NULL,'approved','10','241','0','','1','2026-08-18 19:21:14','2026-08-18 19:19:37','2026-08-18 19:21:14'),
('28','3','vod','https://www.twitch.tv/videos/2849105758','2026-08-17','0',NULL,'approved','11','89','0','','1','2026-08-18 19:26:15','2026-08-18 19:23:40','2026-08-18 19:26:15'),
('29','3','vod','https://www.twitch.tv/videos/2849208965','2026-08-17','0',NULL,'approved','12','57','0','','1','2026-08-18 19:26:38','2026-08-18 19:24:09','2026-08-18 19:26:38'),
('30','3','vod','https://www.twitch.tv/videos/284175231232','2026-08-19','0',NULL,'rejected',NULL,NULL,'0','','1','2026-08-18 23:19:12','2026-08-18 23:18:29','2026-08-18 23:19:12'),
('31','4','vod','','2026-08-19','0',NULL,'rejected',NULL,NULL,'0','','1','2026-08-19 14:43:37','2026-08-19 14:30:45','2026-08-19 14:43:37'),
('32','4','vod','','2026-08-18','0',NULL,'approved','13','348','0','','1','2026-08-20 17:49:38','2026-08-20 15:15:16','2026-08-20 17:49:38'),
('33','4','vod','','2026-08-19','0',NULL,'approved','14','660','0','','1','2026-08-20 17:50:24','2026-08-20 15:17:41','2026-08-20 17:50:24');

DROP TABLE IF EXISTS `penalties`;
CREATE TABLE `penalties` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `streamer_id` int(10) unsigned NOT NULL,
  `type` varchar(100) NOT NULL,
  `description` varchar(255) NOT NULL,
  `points` int(11) NOT NULL DEFAULT 0,
  `penalty_date` date NOT NULL,
  `created_by` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `fk_penalties_streamer` (`streamer_id`),
  KEY `fk_penalties_staff` (`created_by`),
  CONSTRAINT `fk_penalties_staff` FOREIGN KEY (`created_by`) REFERENCES `staff_users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_penalties_streamer` FOREIGN KEY (`streamer_id`) REFERENCES `streamers` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


DROP TABLE IF EXISTS `player_commands`;
CREATE TABLE `player_commands` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(120) NOT NULL,
  `command` varchar(150) NOT NULL,
  `description` varchar(500) NOT NULL,
  `position` int(11) NOT NULL DEFAULT 0,
  `active` tinyint(1) NOT NULL DEFAULT 1,
  `created_by` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `command` (`command`),
  KEY `idx_player_commands_active` (`active`),
  KEY `idx_player_commands_position` (`position`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `player_commands` (`id`,`name`,`command`,`description`,`position`,`active`,`created_by`,`created_at`,`updated_at`) VALUES
('3','Algemar','/cuff','Algema outro jogador, permitindo realizar a contenção durante uma abordagem ou procedimento da Cavalaria.','1','1','1','2026-08-21 11:45:38','2026-08-21 13:16:08'),
('4','Escoltar','/escoltar','Permite escoltar outro jogador, mantendo-o sob acompanhamento durante uma abordagem ou condução.','2','1','1','2026-08-21 11:46:21','2026-08-21 13:16:08'),
('5','Revistar','/revistar','Revista usado da Cavalaria','3','1','1','2026-08-21 11:46:49','2026-08-21 13:16:08'),
('6','Distintivo','/lawbadge','Exibe ou ajusta o distintivo da Cavalaria, permitindo identificar o agente durante o serviço.','4','1','1','2026-08-21 11:47:25','2026-08-21 13:16:08'),
('7','Prender','/prender','Permite realizar a prisão e condução de um jogador conforme os procedimentos da Cavalaria.','5','1','1','2026-08-21 11:48:19','2026-08-21 13:16:08'),
('8','Painel Policial','/mdt','Abre o Painel Policial (MDT), utilizado pela Cavalaria para consultar e acessar informações do serviço.','6','1','1','2026-08-21 11:48:46','2026-08-21 13:16:08'),
('9','Verificar Documento','/pid','Permite verificar a documentação e identificação de um cidadão durante uma abordagem da Cavalaria.','7','1','1','2026-08-21 12:11:26','2026-08-21 13:16:08'),
('10','Revistar Carroça','/vercarroca','Permite revistar uma carroça para verificar seus compartimentos e possíveis itens transportados.','8','1','1','2026-08-21 12:12:04','2026-08-21 13:16:08'),
('11','Chamar Carroça','/chamarcarroca','Solicita uma carroça para atendimento ou transporte, conforme as funções disponíveis ao jogador.','9','1','1','2026-08-21 12:12:46','2026-08-21 13:16:08'),
('12','Levantar Mangas','/sleeve','Levanta as mangas da camisa, alterando a aparência do personagem para determinadas situações ou animações.','10','1','1','2026-08-21 12:14:27','2026-08-21 13:16:08'),
('13','Guardar Carroça','/gc','Guarda a carroça utilizada pelo jogador, retirando-a do local após o uso.','11','1','1','2026-08-21 12:15:14','2026-08-21 13:16:08'),
('14','Animações','/animacao','Abre o menu de animações disponíveis para o personagem, permitindo escolher diferentes ações e poses.','12','1','1','2026-08-21 12:16:21','2026-08-21 13:16:08'),
('15','Anuncio','/anuncio','Envia um anúncio público relacionado aos serviços de Médicos, Cavalaria, Prefeitura e Maquinistas.','13','1','1','2026-08-21 12:17:45','2026-08-21 13:16:08'),
('16','Inspecao','/inspecao','Inicia uma inspeção da arma equipada, permitindo verificar o armamento utilizado pelo personagem.','14','1','1','2026-08-21 12:18:12','2026-08-21 13:16:08'),
('19','Painel Médico','/painel','Abre o menu principal do painel médico para acessar as ferramentas e funções disponíveis aos médicos.','15','1','1','2026-08-21 13:16:20','2026-08-21 13:16:20');

DROP TABLE IF EXISTS `point_transactions`;
CREATE TABLE `point_transactions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `streamer_id` int(10) unsigned NOT NULL,
  `type` enum('earn','penalty','adjustment','redemption_refund') NOT NULL,
  `description` varchar(255) NOT NULL,
  `points` int(11) NOT NULL,
  `reference_type` varchar(50) DEFAULT NULL,
  `reference_id` bigint(20) unsigned DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `fk_points_staff` (`created_by`),
  KEY `idx_points_streamer_date` (`streamer_id`,`created_at`),
  CONSTRAINT `fk_points_staff` FOREIGN KEY (`created_by`) REFERENCES `staff_users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_points_streamer` FOREIGN KEY (`streamer_id`) REFERENCES `streamers` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `point_transactions` (`id`,`streamer_id`,`type`,`description`,`points`,`reference_type`,`reference_id`,`created_by`,`created_at`) VALUES
('19','3','earn','VOD / Live - 16/08/2026','4','vod','10','1','2026-08-18 19:21:14'),
('21','3','earn','VOD / Live - 17/08/2026','1','vod','11','1','2026-08-18 19:26:38'),
('22','3','earn','VOD / Live - 17/08/2026','1','vod','12','1','2026-08-18 19:26:38'),
('23','4','earn','VOD / Live - 18/08/2026','5','vod','13','1','2026-08-20 17:49:38'),
('24','4','earn','VOD / Live - 19/08/2026','11','vod','14','1','2026-08-20 17:50:24');

DROP TABLE IF EXISTS `prizes`;
CREATE TABLE `prizes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(180) NOT NULL,
  `description` text DEFAULT NULL,
  `points_novato` int(10) unsigned NOT NULL DEFAULT 0,
  `points_oficial` int(10) unsigned NOT NULL DEFAULT 0,
  `points_afiliado` int(10) unsigned NOT NULL DEFAULT 0,
  `active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `prizes` (`id`,`name`,`description`,`points_novato`,`points_oficial`,`points_afiliado`,`active`,`created_at`,`updated_at`) VALUES
('1','Caixa de Armas Mediana',NULL,'30','27','25','1','2026-08-18 09:39:56','2026-08-18 09:39:56'),
('2','Caixa de Armas Top',NULL,'90','80','70','1','2026-08-18 09:39:56','2026-08-18 09:39:56'),
('3','Cirurgia',NULL,'45','40','35','1','2026-08-18 09:39:56','2026-08-18 09:39:56'),
('4','Altura Personalizada',NULL,'50','45','40','1','2026-08-18 09:39:56','2026-08-18 09:39:56'),
('5','2º Emprego ou Slot Extra',NULL,'230','200','170','1','2026-08-18 09:39:56','2026-08-18 09:39:56'),
('6','PED - Até 6mb',NULL,'250','230','200','1','2026-08-18 09:39:56','2026-08-18 09:39:56'),
('7','Cavalo - Até $5.000',NULL,'145','125','100','1','2026-08-18 09:39:56','2026-08-18 09:39:56'),
('8','Cavalo - Até $15.000',NULL,'195','170','150','1','2026-08-18 09:39:56','2026-08-18 09:39:56'),
('9','Personalização de Arma',NULL,'140','120','100','1','2026-08-18 09:39:56','2026-08-18 09:39:56'),
('10','Carroça - 500 KG',NULL,'100','80','70','1','2026-08-18 09:39:56','2026-08-18 09:39:56'),
('11','Carroça - 3.000 KG',NULL,'150','130','100','1','2026-08-18 09:39:56','2026-08-18 09:39:56'),
('12','Renovação VIP Platina',NULL,'175','150','130','1','2026-08-18 09:39:56','2026-08-18 09:39:56'),
('13','Renovação VIP Diamante',NULL,'300','275','250','1','2026-08-18 09:39:56','2026-08-18 09:39:56'),
('14','Vitrola','','300','270','250','1','2026-08-18 09:39:56','2026-08-18 23:35:01'),
('15','Resgate - Cupom R$ 250',NULL,'300','275','250','1','2026-08-18 09:39:56','2026-08-18 09:39:56'),
('16','Barco a escolha',NULL,'200','175','150','1','2026-08-18 09:39:56','2026-08-18 09:39:56'),
('17','Balão','','250','230','200','1','2026-08-18 09:39:56','2026-08-18 23:36:45'),
('18','$2.000 (Dinheiro do Condado)','','120','110','100','1','2026-08-18 09:39:56','2026-08-19 17:57:40'),
('19','R$5.000 (Dinheiro do Condado)','','260','250','240','1','2026-08-18 09:39:56','2026-08-19 17:57:58');

DROP TABLE IF EXISTS `raffle_entries`;
CREATE TABLE `raffle_entries` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `raffle_id` bigint(20) unsigned NOT NULL,
  `streamer_id` int(10) unsigned NOT NULL,
  `eligibility_days` int(10) unsigned NOT NULL DEFAULT 0,
  `month_reference` char(7) NOT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_raffle_streamer` (`raffle_id`,`streamer_id`),
  KEY `idx_raffle_entries_raffle` (`raffle_id`),
  KEY `streamer_id` (`streamer_id`),
  CONSTRAINT `raffle_entries_ibfk_1` FOREIGN KEY (`raffle_id`) REFERENCES `raffles` (`id`) ON DELETE CASCADE,
  CONSTRAINT `raffle_entries_ibfk_2` FOREIGN KEY (`streamer_id`) REFERENCES `streamers` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


DROP TABLE IF EXISTS `raffle_winners`;
CREATE TABLE `raffle_winners` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `raffle_id` bigint(20) unsigned NOT NULL,
  `streamer_id` int(10) unsigned NOT NULL,
  `draw_number` int(10) unsigned NOT NULL DEFAULT 1,
  `drawn_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_raffle_winner` (`raffle_id`,`streamer_id`),
  KEY `streamer_id` (`streamer_id`),
  CONSTRAINT `raffle_winners_ibfk_1` FOREIGN KEY (`raffle_id`) REFERENCES `raffles` (`id`) ON DELETE CASCADE,
  CONSTRAINT `raffle_winners_ibfk_2` FOREIGN KEY (`streamer_id`) REFERENCES `streamers` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `raffle_winners` (`id`,`raffle_id`,`streamer_id`,`draw_number`,`drawn_at`) VALUES
('1','1','2','1','2026-08-18 14:22:35');

DROP TABLE IF EXISTS `raffles`;
CREATE TABLE `raffles` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(180) NOT NULL,
  `description` text DEFAULT NULL,
  `prize` varchar(255) NOT NULL,
  `draw_date` date DEFAULT NULL,
  `draw_time` time DEFAULT NULL,
  `winners_count` int(10) unsigned NOT NULL DEFAULT 1,
  `entry_points` int(10) unsigned NOT NULL DEFAULT 0,
  `eligibility_text` varchar(500) DEFAULT NULL,
  `active` tinyint(1) NOT NULL DEFAULT 0,
  `created_by` int(10) unsigned DEFAULT NULL,
  `webhook_url` varchar(500) DEFAULT NULL,
  `drawn_at` datetime DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_raffles_active` (`active`),
  KEY `created_by` (`created_by`),
  CONSTRAINT `raffles_ibfk_1` FOREIGN KEY (`created_by`) REFERENCES `staff_users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `raffles` (`id`,`title`,`description`,`prize`,`draw_date`,`draw_time`,`winners_count`,`entry_points`,`eligibility_text`,`active`,`created_by`,`webhook_url`,`drawn_at`,`created_at`,`updated_at`) VALUES
('1','Sorteio do Mês','teste','Batata','2026-08-18','18:20:00','1','0','Sorteio Teste','0','1','https://discord.com/api/webhooks/1539382690627850251/J8gddlMlNkSo1d2dBwls6HdMHp_CBSLaSJu3z2JqBAMi_YgtlgRvT7wfNgLXpfaHRYKC','2026-08-18 14:22:35','2026-08-18 14:17:48','2026-08-18 14:22:35');

DROP TABLE IF EXISTS `redemptions`;
CREATE TABLE `redemptions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `streamer_id` int(10) unsigned NOT NULL,
  `prize_id` int(10) unsigned NOT NULL,
  `streamer_category` enum('novato','oficial','afiliado') NOT NULL,
  `points_spent` int(10) unsigned NOT NULL,
  `status` enum('pending','approved','delivered','cancelled') NOT NULL DEFAULT 'pending',
  `approved_by` int(10) unsigned DEFAULT NULL,
  `delivered_by` int(10) unsigned DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `staff_notes` text DEFAULT NULL,
  `reviewed_by` int(10) unsigned DEFAULT NULL,
  `reviewed_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_redemptions_streamer` (`streamer_id`),
  KEY `fk_redemptions_prize` (`prize_id`),
  KEY `fk_redemptions_approved` (`approved_by`),
  KEY `fk_redemptions_delivered` (`delivered_by`),
  CONSTRAINT `fk_redemptions_approved` FOREIGN KEY (`approved_by`) REFERENCES `staff_users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_redemptions_delivered` FOREIGN KEY (`delivered_by`) REFERENCES `staff_users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_redemptions_prize` FOREIGN KEY (`prize_id`) REFERENCES `prizes` (`id`),
  CONSTRAINT `fk_redemptions_streamer` FOREIGN KEY (`streamer_id`) REFERENCES `streamers` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


DROP TABLE IF EXISTS `settings`;
CREATE TABLE `settings` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `setting_key` varchar(100) NOT NULL,
  `setting_value` text NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `setting_key` (`setting_key`)
) ENGINE=InnoDB AUTO_INCREMENT=47 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `settings` (`id`,`setting_key`,`setting_value`,`description`,`updated_at`) VALUES
('1','live_points_per_hour','1','Pontos por hora completa','2026-08-18 14:03:02'),
('2','live_max_points','12','Máximo por VOD','2026-08-19 14:05:39'),
('3','official_weekly_lives','3','Lives mínimas Oficial','2026-08-18 09:39:56'),
('4','official_min_live_hours','2','Horas mínimas por live Oficial','2026-08-18 09:39:56'),
('5','official_weekly_short_content','1','Conteúdos curtos Oficial','2026-08-18 09:39:56'),
('6','affiliate_weekly_lives','3','Lives mínimas Afiliado','2026-08-18 09:39:56'),
('7','affiliate_min_live_hours','3','Horas mínimas por live Afiliado','2026-08-18 09:39:56'),
('8','affiliate_weekly_short_content','2','Conteúdos curtos Afiliado','2026-08-18 09:39:56'),
('9','weekly_video_points_limit','30','Limite semanal de vídeos','2026-08-18 09:39:56'),
('10','weekly_viral_video_points_limit','60','Limite semanal de viralizados','2026-08-18 09:39:56'),
('11','vod_daily_points_migrated','1','VODs existentes recalculadas pela regra diária','2026-08-18 09:58:48'),
('12','streamer_background','assets/uploads/streamer/background_20260819031853_0a079129.png','Background da Área do Streamer','2026-08-19 00:18:53'),
('15','collab_raid_points','3','Pontos por Collab/Raid com outro streamer do Condado','2026-08-18 13:18:31'),
('16','social_common_points','3','Pontos por Link Comum','2026-08-18 13:18:31'),
('17','social_humor_points','10','Pontos por Vídeo Humorístico','2026-08-19 14:05:39'),
('18','social_news_points','5','Pontos por Vídeo de Novidades','2026-08-19 14:05:39'),
('19','weekly_social_points_limit','30','Limite semanal de pontos por conteúdos de redes sociais','2026-08-18 13:18:31'),
('20','monthly_live_days_target','20','Dias distintos com live aprovados no mês para atingir a meta','2026-08-18 13:18:31'),
('21','monthly_live_days_bonus','50','Bônus por atingir a meta mensal de dias com live','2026-08-18 13:18:31'),
('25','weekly_live_days_target','5','Dias distintos com live aprovados na semana para atingir a meta','2026-08-19 14:05:39'),
('26','weekly_live_days_bonus','5','Bônus por atingir a meta semanal de dias com live','2026-08-19 14:05:39'),
('27','weekly_live_hours_target','25','Horas completas de live aprovadas na semana para atingir a meta','2026-08-19 14:05:39'),
('28','weekly_live_hours_bonus','5','Bônus por atingir a meta semanal de horas com live','2026-08-19 14:05:39'),
('29','proof_retention_days','7','Quantidade de dias para manter os comprovantes de VOD antes da exclusão automática','2026-08-19 14:48:36'),
('30','redemption_cooldown_days','7','Quantidade de dias entre resgates aprovados do mesmo streamer','2026-08-19 14:45:58'),
('31','discord_ranking_key','10244a0e389ff81af792db4840416e8465e7f713db36c8b8','Chave privada do endpoint de atualização do ranking Discord.','2026-08-20 18:37:44'),
('32','discord_ranking_message_id','1540220014454505526','ID da mensagem do ranking no Discord.','2026-08-20 21:44:29'),
('33','discord_ranking_footer_image','https://discord.com/api/webhooks/1540216217552560138/NC1VvHzPaRx0jj_zYvPDnKuFVJzpE5AYRFi0jULQzKFspsqDUCA_mnppcNTs0jMCTf4H','Ícone do rodapé do Embed (desativado).','2026-08-20 21:30:26'),
('34','discord_ranking_webhook','https://discord.com/api/webhooks/1540216217552560138/NC1VvHzPaRx0jj_zYvPDnKuFVJzpE5AYRFi0jULQzKFspsqDUCA_mnppcNTs0jMCTf4H','Webhook do ranking público Nevada Creators.','2026-08-20 21:39:09'),
('35','discord_ranking_bottom_image','https://nevadacreators.gamer.free/assets/uploads/discord/ranking_20260821003924_e6f77a71.png','Imagem grande do ranking Nevada Creators.','2026-08-20 21:39:24'),
('36','discord_relay_url','https://morningfall-relay.santourso.workers.dev','URL base do Cloudflare Worker usado pelo Discord Relay.','2026-08-20 21:35:19'),
('37','discord_relay_secret','MorningfallRelay_2026_X7p9K2mQ8vL4','Mesmo valor do Secret RELAY_SECRET configurado no Cloudflare Worker.','2026-08-20 21:35:19'),
('38','players_public_logo','assets/uploads/players_public/logo_20260821162009_24001798.webp','Logo da página pública de Comandos Básicos de Players','2026-08-21 13:20:10'),
('40','players_public_background','assets/uploads/players_public/background_20260821161956_3ab70cb1.webp','Background da página pública de Comandos Básicos de Players','2026-08-21 13:19:57');

DROP TABLE IF EXISTS `staff_commands_settings`;
CREATE TABLE `staff_commands_settings` (
  `id` tinyint(3) unsigned NOT NULL,
  `top_name` varchar(100) NOT NULL DEFAULT 'NEVADA STAFF',
  `eyebrow_name` varchar(150) NOT NULL DEFAULT 'NEVADA ROLEPLAY · STAFF',
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `staff_commands_settings` (`id`,`top_name`,`eyebrow_name`,`updated_at`) VALUES
('1','NEVADA STAFF','NEVADA ROLEPLAY · STAFF','2026-08-21 07:10:18');

DROP TABLE IF EXISTS `staff_coordinate_categories`;
CREATE TABLE `staff_coordinate_categories` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `icon` varchar(20) NOT NULL DEFAULT '?',
  `active` tinyint(1) NOT NULL DEFAULT 1,
  `created_by` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`),
  KEY `fk_staff_coord_categories_created_by` (`created_by`),
  CONSTRAINT `fk_staff_coord_categories_created_by` FOREIGN KEY (`created_by`) REFERENCES `staff_users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=343 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `staff_coordinate_categories` (`id`,`name`,`icon`,`active`,`created_by`,`created_at`,`updated_at`) VALUES
('1','Empresas','🏢','1','1','2026-08-21 07:37:10','2026-08-21 07:37:10'),
('2','Fazendas','🌾','1','1','2026-08-21 07:37:10','2026-08-21 07:37:10'),
('3','Casas','🏠','1','1','2026-08-21 07:37:10','2026-08-21 07:37:10'),
('4','Bandoleiro','👥','1','1','2026-08-21 07:37:10','2026-08-21 07:47:18'),
('5','Sobrenatural','👻','1','1','2026-08-21 07:37:10','2026-08-21 07:37:10'),
('6','Legal','⭐','1','1','2026-08-21 07:37:10','2026-08-21 07:37:44'),
('130','Grupos','👥','1','1','2026-08-21 07:47:18','2026-08-21 07:47:18');

DROP TABLE IF EXISTS `staff_coordinate_seed_state`;
CREATE TABLE `staff_coordinate_seed_state` (
  `id` tinyint(3) unsigned NOT NULL,
  `initialized_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `staff_coordinate_seed_state` (`id`,`initialized_at`) VALUES
('1','2026-08-21 08:29:46');

DROP TABLE IF EXISTS `staff_coordinate_subcategories`;
CREATE TABLE `staff_coordinate_subcategories` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `category_id` int(10) unsigned NOT NULL,
  `name` varchar(100) NOT NULL,
  `icon` varchar(20) NOT NULL DEFAULT '?',
  `active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_coord_subcategory` (`category_id`,`name`),
  CONSTRAINT `fk_staff_coord_subcategories_category` FOREIGN KEY (`category_id`) REFERENCES `staff_coordinate_categories` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=858 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `staff_coordinate_subcategories` (`id`,`category_id`,`name`,`icon`,`active`,`created_at`,`updated_at`) VALUES
('1','1','Saloons','🥧','1','2026-08-21 07:37:10','2026-08-21 08:18:21'),
('2','1','Ferrarias','🔨','1','2026-08-21 07:37:10','2026-08-21 08:18:21'),
('3','1','Tabacarias','🚬','1','2026-08-21 07:37:10','2026-08-21 08:18:21'),
('4','1','Artesanatos','🎭','1','2026-08-21 07:37:10','2026-08-21 08:18:21'),
('5','1','Armarias','🔫','1','2026-08-21 07:37:10','2026-08-21 08:18:21'),
('6','1','Ateliês','🎀','1','2026-08-21 07:37:10','2026-08-21 08:18:21'),
('7','1','Perfumarias','🌸','1','2026-08-21 07:37:10','2026-08-21 08:18:21'),
('8','1','Jornais','📄','1','2026-08-21 07:37:10','2026-08-21 08:18:21'),
('9','1','Geral','📍','1','2026-08-21 07:37:10','2026-08-21 07:37:10'),
('10','2','Geral','📍','1','2026-08-21 07:37:10','2026-08-21 07:37:10'),
('11','3','Casa','🏠','1','2026-08-21 07:37:10','2026-08-21 08:18:21'),
('12','4','Bandoleiro 1','💀','1','2026-08-21 07:37:10','2026-08-21 08:18:21'),
('13','5','Bruxa','🧙‍♂️','1','2026-08-21 07:37:10','2026-08-21 08:18:22'),
('14','6','Cavalaria','⭐','1','2026-08-21 07:37:10','2026-08-21 08:18:21'),
('15','6','Tribunal','💼','1','2026-08-21 07:37:10','2026-08-21 08:18:21'),
('46','5','Lobisomen','🧔','1','2026-08-21 07:38:31','2026-08-21 08:18:22'),
('328','130','Geral','📍','1','2026-08-21 07:47:18','2026-08-21 07:47:18'),
('347','6','Hospital','💉','1','2026-08-21 07:49:10','2026-08-21 08:18:21'),
('748','3','Geral','📍','1','2026-08-21 08:25:35','2026-08-21 08:25:35'),
('750','5','Geral','📍','1','2026-08-21 08:25:35','2026-08-21 08:25:35');

DROP TABLE IF EXISTS `staff_coordinates`;
CREATE TABLE `staff_coordinates` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `category` varchar(100) NOT NULL,
  `subcategory` varchar(100) NOT NULL DEFAULT 'Geral',
  `icon` varchar(20) NOT NULL DEFAULT '?',
  `name` varchar(180) NOT NULL,
  `cds` varchar(255) NOT NULL,
  `position` int(11) NOT NULL DEFAULT 0,
  `active` tinyint(1) NOT NULL DEFAULT 1,
  `created_by` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `fk_staff_coordinates_created_by` (`created_by`),
  KEY `idx_staff_coordinates_category` (`category`),
  KEY `idx_staff_coordinates_active` (`active`),
  KEY `idx_staff_coordinates_name` (`name`),
  KEY `idx_staff_coordinates_subcategory` (`subcategory`),
  CONSTRAINT `fk_staff_coordinates_created_by` FOREIGN KEY (`created_by`) REFERENCES `staff_users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=46 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `staff_coordinates` (`id`,`category`,`subcategory`,`icon`,`name`,`cds`,`position`,`active`,`created_by`,`created_at`,`updated_at`) VALUES
('1','Empresas','Saloons','🍺','Saloon de Valentine','-314.88 808.61 118.99','1','1','1','2026-08-21 06:50:33','2026-08-21 06:58:06'),
('2','Empresas','Saloons','🍺','Saloon de Blackwater','-819.77 -1318.13 43.68','2','1','1','2026-08-21 06:50:33','2026-08-21 06:58:06'),
('3','Empresas','Saloons','🍺','Saloon de Rhodes','1340.1748 -1374.819 80.480606','3','1','1','2026-08-21 06:50:33','2026-08-21 06:58:06'),
('4','Empresas','Saloons','🍺','Saloon de Saint Denis 1','2792.3723 -1168.412 47.932285','4','1','1','2026-08-21 06:50:33','2026-08-21 06:58:06'),
('5','Empresas','Saloons','🍺','Saloon de Saint Denis 2','2640.2153 -1228.2874 53.380486','5','1','1','2026-08-21 06:50:33','2026-08-21 06:58:06'),
('6','Empresas','Saloons','🍺','Saloon de Van Horn','2947.8439 528.06262 45.338794','6','1','1','2026-08-21 06:50:33','2026-08-21 06:58:06'),
('7','Empresas','Saloons','🍺','Saloon de Armadillo','-3699.808 -2594.406 -13.31987','7','1','1','2026-08-21 06:50:33','2026-08-21 06:58:06'),
('8','Empresas','Saloons','🍺','Saloon de Tumbleweed','-5518.478 -2906.511 -1.751306','8','1','1','2026-08-21 06:50:33','2026-08-21 06:58:06'),
('9','Empresas','Ferrarias','🔨','Ferraria Valentine','-323.7358 717.5155 121.698402','9','1','1','2026-08-21 06:50:33','2026-08-21 06:58:06'),
('10','Empresas','Ferrarias','🔨','Ferraria Saint Dennis','2379.2478 -1435.2996 47.166542','10','1','1','2026-08-21 06:50:33','2026-08-21 06:58:06'),
('11','Empresas','Ferrarias','🔨','Ferraria Blackwater','-871.7198 -1263.5057 43.603016','11','1','1','2026-08-21 06:50:33','2026-08-21 06:58:06'),
('12','Empresas','Tabacarias','🚬','Tabacaria Rhodes','1325.8912 -1200.2056 82.538246','12','1','1','2026-08-21 06:50:33','2026-08-21 06:58:06'),
('13','Empresas','Tabacarias','🚬','Tabacaria Strawberry','-1704.6758 -465.1711 150.504944','13','1','1','2026-08-21 06:50:33','2026-08-21 06:58:06'),
('14','Empresas','Artesanatos','🎨','Artesanato Rhodes','1314.0377 -1251.4417 79.092972','14','1','1','2026-08-21 06:50:33','2026-08-21 06:58:06'),
('15','Empresas','Artesanatos','🎨','Artesanato Saint Denis','2361.9587 -1356.9808 46.908798','15','1','1','2026-08-21 06:50:33','2026-08-21 06:58:06'),
('16','Empresas','Artesanatos','🎨','Artesanato Blackwater','-874.6288 -1233.1938 43.811287','16','1','1','2026-08-21 06:50:33','2026-08-21 06:58:06'),
('17','Empresas','Artesanatos','🎨','Artesanato Emerald','1335.4728 334.4643 87.897560','17','1','1','2026-08-21 06:50:33','2026-08-21 06:58:06'),
('18','Empresas','Artesanatos','🎨','Artesanato Valentine','-336.7295 683.5873 117.302757','18','1','1','2026-08-21 06:50:33','2026-08-21 06:58:06'),
('19','Empresas','Artesanatos','🎨','Artesanato Strawberry','-1734.7554 -434.1190 152.741470','19','1','1','2026-08-21 06:50:33','2026-08-21 06:58:06'),
('20','Empresas','Artesanatos','🎨','Artesanato Van Horn','3003.3926 572.1270 44.917122','20','1','1','2026-08-21 06:50:33','2026-08-21 06:58:06'),
('21','Empresas','Ferrarias','🔨','Ferraria Rhodes','1397.5062 -1323.1259 78.402626','21','1','1','2026-08-21 06:50:33','2026-08-21 06:58:06'),
('22','Empresas','Ferrarias','🔨','Ferraria Saint Denis','2367.1182 -1432.1681 47.142326','22','1','1','2026-08-21 06:50:33','2026-08-21 06:58:06'),
('23','Empresas','Ferrarias','🔨','Ferraria Blackwater','-871.8726 -1256.8027 44.221558','23','1','1','2026-08-21 06:50:33','2026-08-21 06:58:06'),
('24','Empresas','Ferrarias','🔨','Ferraria Valentine','-312.4471 715.6888 117.934631','24','1','1','2026-08-21 06:50:33','2026-08-21 06:58:06'),
('25','Empresas','Ferrarias','🔨','Ferraria Strawberry','-1827.7865 -602.1822 155.039841','25','1','1','2026-08-21 06:50:33','2026-08-21 06:58:06'),
('26','Empresas','Ferrarias','🔨','Ferraria Van Horn','2933.3525 569.2667 44.968082','26','1','1','2026-08-21 06:50:33','2026-08-21 06:58:06'),
('27','Empresas','Armarias','🔫','Armaria Rhodes','1323.7992 -1321.8015 77.889778','27','1','1','2026-08-21 06:50:33','2026-08-21 06:58:06'),
('28','Empresas','Armarias','🔫','Armaria Saint Denis','2717.6025 -1284.9991 49.630501','28','1','1','2026-08-21 06:50:33','2026-08-21 06:58:06'),
('29','Empresas','Armarias','🔫','Armaria Emerald','1307.7291 279.7158 89.141212','29','1','1','2026-08-21 06:50:33','2026-08-21 06:58:06'),
('30','Empresas','Armarias','🔫','Armaria Valentine','-280.4661 780.7427 119.527100','30','1','1','2026-08-21 06:50:33','2026-08-21 06:58:06'),
('31','Empresas','Armarias','🔫','Armaria Strawberry','-1821.3944 -664.4064 151.957779','31','1','1','2026-08-21 06:50:33','2026-08-21 06:58:06'),
('32','Empresas','Ateliês','✂️','Ateliê Saint Denis','2587.7869 -1010.1629 44.239948','32','1','1','2026-08-21 06:50:33','2026-08-21 06:58:06'),
('33','Empresas','Ateliês','✂️','Ateliê Blackwater','-827.7024 -1232.4222 43.804985','33','1','1','2026-08-21 06:50:33','2026-08-21 06:58:06'),
('34','Empresas','Ateliês','✂️','Ateliê Emerald','1335.4728 334.4643 87.897560','34','1','1','2026-08-21 06:50:33','2026-08-21 06:58:06'),
('35','Empresas','Perfumarias','🌹','Perfumaria Saint Denis','2344.9531 -1374.2511 46.596611','35','1','1','2026-08-21 06:50:33','2026-08-21 06:58:06'),
('36','Empresas','Perfumarias','🌹','Perfumaria Blackwater','-753.9659 -1179.1790 44.214500','36','1','1','2026-08-21 06:50:33','2026-08-21 06:58:06'),
('37','Empresas','Perfumarias','🌹','Perfumaria Emerald','1345.9099 287.3472 88.706886','37','1','1','2026-08-21 06:50:33','2026-08-21 06:58:06'),
('38','Empresas','Jornais','📰','Jornal Saint Denis','2391.4458 -1355.5328 45.883583','38','1','1','2026-08-21 06:50:33','2026-08-21 06:58:06'),
('39','Empresas','Jornais','📰','Jornal Blackwater','-852.1503 -1207.7109 43.453747','39','1','1','2026-08-21 06:50:33','2026-08-21 06:58:06'),
('40','Legal','Cavalaria','🐎','Posto de Polícia Valentine','-278.42 805.29 119.38','40','1','1','2026-08-21 07:37:10','2026-08-21 07:37:44'),
('41','Legal','Cavalaria','🐎','Posto de Polícia Rhodes','1362.04 -1302.10 77.77','41','1','1','2026-08-21 07:37:10','2026-08-21 07:37:44'),
('42','Legal','Cavalaria','🐎','Posto de Polícia Blackwater','-761.76 -1268.18 44.04','42','1','1','2026-08-21 07:37:10','2026-08-21 07:37:44'),
('43','Legal','Cavalaria','🐎','Posto de Polícia Strawberry','-1811.95 -353.94 164.65','43','1','1','2026-08-21 07:37:10','2026-08-21 07:37:44'),
('44','Legal','Cavalaria','🐎','Posto de Polícia Saint Denis','2507.72 -1301.89 48.95','44','1','1','2026-08-21 07:37:10','2026-08-21 07:37:44'),
('45','Legal','Cavalaria','🐎','Posto de Polícia Armadillo','-3622.85 -2603.52 -13.34','45','1','1','2026-08-21 07:37:10','2026-08-21 07:37:44');

DROP TABLE IF EXISTS `staff_users`;
CREATE TABLE `staff_users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(120) NOT NULL,
  `username` varchar(80) NOT NULL,
  `discord_id` varchar(32) DEFAULT NULL,
  `discord_avatar` varchar(700) DEFAULT NULL,
  `password_hash` varchar(255) NOT NULL,
  `role` enum('master','staff') NOT NULL DEFAULT 'staff',
  `active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `staff_users` (`id`,`name`,`username`,`discord_id`,`discord_avatar`,`password_hash`,`role`,`active`,`created_at`) VALUES
('1','Mod Luci','luci','207712204890439680','https://cdn.discordapp.com/avatars/207712204890439680/bf103cfd7e4b93e69857e1cd6b34de4a.png?size=256','$2y$10$W.znBPfurouZ/6tVcKQ6aej8gdD0S39fm5JA9bR80TYQvoA5Rb43a','master','1','2026-08-18 09:41:06'),
('6','Queen','Queen','126820181094694912','https://cdn.discordapp.com/avatars/126820181094694912/2f709e368c372d75139252be66a26c09.png?size=256','$2y$10$SPCXP01alZeeUFf/Jx5c1Oo8p7LYAXuvMt93xl4k41PNDRneN/t3O','master','1','2026-08-18 16:32:23'),
('8','Coruja','coruja','1344736733627154452','https://cdn.discordapp.com/avatars/1344736733627154452/59b281361d24213e4ddbd95863a921b2.png?size=256','$2y$10$QHc6rWpAQVdS8Q3nsmYuUOsa34KKmVzdPbJEeoTt8BUUXtEwXiTgi','master','1','2026-08-20 13:43:43');

DROP TABLE IF EXISTS `streamers`;
CREATE TABLE `streamers` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(120) NOT NULL,
  `discord` varchar(120) DEFAULT NULL,
  `discord_id` varchar(32) DEFAULT NULL,
  `discord_avatar` varchar(700) DEFAULT NULL,
  `platform` varchar(50) DEFAULT NULL,
  `channel_url` varchar(500) DEFAULT NULL,
  `category` enum('novato','oficial','afiliado') NOT NULL DEFAULT 'novato',
  `access_code` varchar(100) NOT NULL,
  `points` int(11) NOT NULL DEFAULT 0,
  `active` tinyint(1) NOT NULL DEFAULT 1,
  `joined_at` date DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `webhook_url` varchar(500) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `access_code` (`access_code`),
  KEY `idx_category` (`category`),
  KEY `idx_active` (`active`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `streamers` (`id`,`name`,`discord`,`discord_id`,`discord_avatar`,`platform`,`channel_url`,`category`,`access_code`,`points`,`active`,`joined_at`,`notes`,`webhook_url`,`created_at`,`updated_at`) VALUES
('2','Lua Colin','1301699180183425044','1301699180183425044','https://cdn.discordapp.com/avatars/1301699180183425044/a_ca68227bd4ba2f9a21748e760659100f.gif?size=256','Twitch','https://www.twitch.tv/luazinha_ofc','afiliado','U0B9WFP4','6','1','2026-08-18','','https://discord.com/api/webhooks/1539339630111891617/ES-aKUHaGxtLOX-gA-Jsw0dq4f1hcvwTTBaTEHi-oL-Jp656X6_fmT5XSt6LLzIe3nqx','2026-08-18 11:30:43','2026-08-18 19:28:01'),
('3','Letti','724878610753781780','724878610753781780','https://cdn.discordapp.com/avatars/724878610753781780/9bd6cfedbd2ac326631409d4513da199.png?size=256','Twitch','','novato','5B5NOQ5Y','6','1','2026-08-18','','https://discord.com/api/webhooks/1539339630111891617/ES-aKUHaGxtLOX-gA-Jsw0dq4f1hcvwTTBaTEHi-oL-Jp656X6_fmT5XSt6LLzIe3nqx','2026-08-18 19:16:43','2026-08-18 23:09:01'),
('4','Mákhawi','618837942877552670','618837942877552670','https://cdn.discordapp.com/avatars/618837942877552670/fe317cd37fa6777dbfa45b7340ee2d18.png?size=256','Tiktok','https://www.tiktok.com/@marconerp','afiliado','EFCYUJO5','16','1','2026-08-19','','https://discord.com/api/webhooks/1539339630111891617/ES-aKUHaGxtLOX-gA-Jsw0dq4f1hcvwTTBaTEHi-oL-Jp656X6_fmT5XSt6LLzIe3nqx','2026-08-18 23:08:28','2026-08-20 17:50:24'),
('5','Queen','126820181094694912','126820181094694912','https://cdn.discordapp.com/avatars/126820181094694912/2f709e368c372d75139252be66a26c09.png?size=256','Twitch','','novato','HDBXM77W','0','0','2026-08-19','','https://discord.com/api/webhooks/1539339630111891617/ES-aKUHaGxtLOX-gA-Jsw0dq4f1hcvwTTBaTEHi-oL-Jp656X6_fmT5XSt6LLzIe3nqx','2026-08-19 06:08:43','2026-08-20 21:47:41'),
('6','coruja','1344736733627154452','1344736733627154452','https://cdn.discordapp.com/avatars/1344736733627154452/59b281361d24213e4ddbd95863a921b2.png?size=256','Twitch','','novato','XOF1HXUV','0','0','2026-08-20','',NULL,'2026-08-20 13:49:28','2026-08-20 21:47:47');

DROP TABLE IF EXISTS `vods`;
CREATE TABLE `vods` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `streamer_id` int(10) unsigned NOT NULL,
  `url` varchar(700) NOT NULL,
  `vod_date` date NOT NULL,
  `duration_minutes` int(10) unsigned NOT NULL DEFAULT 0,
  `points_awarded` int(11) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_vod_streamer` (`streamer_id`,`vod_date`),
  CONSTRAINT `fk_vods_streamer` FOREIGN KEY (`streamer_id`) REFERENCES `streamers` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `vods` (`id`,`streamer_id`,`url`,`vod_date`,`duration_minutes`,`points_awarded`,`created_at`) VALUES
('1','2','https://www.twitch.tv/videos/2841752312','2026-08-09','46','0','2026-08-18 13:29:19'),
('2','2','https://www.twitch.tv/videos/2841608682','2026-08-09','52','1','2026-08-18 13:29:44'),
('3','2','https://www.twitch.tv/videos/2840590620','2026-08-08','57','0','2026-08-18 13:30:06'),
('4','2','https://www.twitch.tv/videos/2840014855','2026-08-07','119','1','2026-08-18 13:30:31'),
('5','2','https://www.twitch.tv/videos/2839988593','2026-08-07','32','1','2026-08-18 13:30:56'),
('6','2','https://www.twitch.tv/videos/2839626392','2026-08-07','39','1','2026-08-18 13:31:20'),
('7','2','https://www.twitch.tv/videos/2838216325','2026-08-05','113','1','2026-08-18 13:31:42'),
('8','2','https://www.twitch.tv/videos/2837373347','2026-08-04','41','0','2026-08-18 13:32:07'),
('9','2','https://www.twitch.tv/videos/2837067903','2026-08-04','42','1','2026-08-18 13:32:25'),
('10','3','https://www.twitch.tv/videos/2848380325','2026-08-16','241','4','2026-08-18 19:21:14'),
('11','3','https://www.twitch.tv/videos/2849105758','2026-08-17','89','1','2026-08-18 19:26:15'),
('12','3','https://www.twitch.tv/videos/2849208965','2026-08-17','57','1','2026-08-18 19:26:38'),
('13','4','','2026-08-18','348','5','2026-08-20 17:49:38'),
('14','4','','2026-08-19','660','11','2026-08-20 17:50:24');

SET FOREIGN_KEY_CHECKS=1;
